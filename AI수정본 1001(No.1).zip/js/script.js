// 모든 nav 메뉴 링크를 선택
const navLinks = document.querySelectorAll('.navMenu a');

// 각 링크에 클릭 이벤트 추가
navLinks.forEach(link => {
  link.addEventListener('click', function(e) {
    e.preventDefault(); // 일단 이 줄은 유지
    
    // 모든 링크에서 active 클래스 제거
    navLinks.forEach(l => l.classList.remove('active'));
    
    // 클릭한 링크에만 active 클래스 추가
    this.classList.add('active');
    
    console.log('클릭됨:', this.textContent); // 테스트용
  });
});